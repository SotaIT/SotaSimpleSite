namespace Sota.Web.UI.WebControls
{
    public enum VerticalAlignment
    {
        NotSet,
        Top,
        Middle,
        Bottom
    }
}

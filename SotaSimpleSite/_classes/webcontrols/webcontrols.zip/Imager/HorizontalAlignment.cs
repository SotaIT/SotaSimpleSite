namespace Sota.Web.UI.WebControls
{
    public enum HorizontalAlignment
    {
        NotSet,
        Left,
        Center,
        Right
    }
}

namespace Sota.Web.UI.WebControls
{
    public enum WebImageFormat
    {
        Auto,
        Png,
        Jpeg,
        Gif,
        Bmp
    }
}
